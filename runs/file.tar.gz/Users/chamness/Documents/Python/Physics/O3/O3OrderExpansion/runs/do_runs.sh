#!/bin/bash

python3 deltaS.py 0.0
python3 deltaS.py 0.2
python3 deltaS.py 0.4
python3 deltaS.py 0.6
python3 deltaS.py 0.8
python3 deltaS.py 1.0
python3 deltaS.py 1.2
